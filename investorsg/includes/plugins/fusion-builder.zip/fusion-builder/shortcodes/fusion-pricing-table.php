<?php

/**
 * Shortcode class.
 *
 * @package fusion-builder
 * @since 1.0
 */
class FusionSC_PricingTable {

	/**
	 * The pricing table counter.
	 *
	 * @access private
	 * @since 1.0
	 * @var int
	 */
	private $pricing_table_counter = 1;

	/**
	 * True if this is the first row, otherwise false.
	 *
	 * @access private
	 * @since 1.0
	 * @var bool
	 */
	private $is_first_row = true;

	/**
	 * True if this is the first column, otherwise defaults to false.
	 *
	 * @access private
	 * @since 1.0
	 * @var bool
	 */
	private $is_first_column = true;

	/**
	 * True if this is the list group is closed, otherwise false.
	 *
	 * @access private
	 * @since 1.0
	 * @var bool
	 */
	private $is_list_group_closed = false;

	/**
	 * Parent SC arguments.
	 *
	 * @static
	 * @access public
	 * @since 1.0
	 * @var array
	 */
	public static $parent_args;

	/**
	 * Arguments for the column.
	 *
	 * @static
	 * @access public
	 * @since 1.0
	 * @var array
	 */
	public static $child_column_args;

	/**
	 * Constructor.
	 *
	 * @access public
	 * @since 1.0
	 */
	public function __construct() {

		add_filter( 'fusion_attr_pricingtable-shortcode', array( $this, 'attr' ) );
		add_filter( 'fusion_attr_pricingtable-shortcode-column-wrapper', array( $this, 'column_wrapper_attr' ) );
		add_filter( 'fusion_attr_pricingtable-shortcode-price', array( $this, 'price_attr' ) );
		add_filter( 'fusion_attr_pricingtable-shortcode-row', array( $this, 'row_attr' ) );
		add_filter( 'fusion_attr_pricingtable-shortcode-footer', array( $this, 'footer_attr' ) );

		add_shortcode( 'fusion_pricing_table', array( $this, 'render_parent' ) );
		add_shortcode( 'fusion_pricing_column', array( $this, 'render_child_column' ) );
		add_shortcode( 'fusion_pricing_price', array( $this, 'render_child_price' ) );
		add_shortcode( 'fusion_pricing_row', array( $this, 'render_child_row' ) );
		add_shortcode( 'fusion_pricing_footer', array( $this, 'render_child_footer' ) );

	}

	/**
	 * Render the parent shortcode
	 *
	 * @access public
	 * @since 1.0
	 * @param  array  $args    Shortcode parameters.
	 * @param  string $content Content between shortcode.
	 * @return string          HTML output.
	 */
	public function render_parent( $args, $content = '' ) {

		$defaults = FusionBuilder::set_shortcode_defaults(
			array(
				'hide_on_mobile'  => fusion_builder_default_visibility( 'string' ),
				'class'           => '',
				'id'              => '',
				'backgroundcolor' => FusionBuilder::get_theme_option( 'pricing_bg_color' ),
				'bordercolor'     => FusionBuilder::get_theme_option( 'pricing_border_color' ),
				'columns'         => '',
				'dividercolor'    => FusionBuilder::get_theme_option( 'pricing_divider_color' ),
				'type'            => '1',
			), $args
		);

		extract( $defaults );

		self::$parent_args = $defaults;

		self::$parent_args['columns'] = min( self::$parent_args['columns'], 6 );

		$this->set_num_of_columns( $content );

		$this->is_first_column = true;

		$styles = "<style type='text/css'>
		.pricing-table-{$this->pricing_table_counter} .panel-container, .pricing-table-{$this->pricing_table_counter} .standout .panel-container,
		.pricing-table-{$this->pricing_table_counter}.full-boxed-pricing {background-color:{$bordercolor};}
		.pricing-table-{$this->pricing_table_counter} .list-group .list-group-item,
		.pricing-table-{$this->pricing_table_counter} .list-group .list-group-item:last-child{background-color:{$backgroundcolor}; border-color:{$dividercolor};}
		.pricing-table-{$this->pricing_table_counter}.full-boxed-pricing .panel-wrapper:hover .panel-heading,
		.pricing-table-{$this->pricing_table_counter} .panel-wrapper:hover .list-group-item {background-color:$bordercolor;}
		.pricing-table-{$this->pricing_table_counter}.full-boxed-pricing .panel-heading{background-color:{$backgroundcolor};}
		.pricing-table-{$this->pricing_table_counter} .fusion-panel, .pricing-table-{$this->pricing_table_counter} .panel-wrapper:last-child .fusion-panel,
		.pricing-table-{$this->pricing_table_counter} .standout .fusion-panel, .pricing-table-{$this->pricing_table_counter}  .panel-heading,
		.pricing-table-{$this->pricing_table_counter} .panel-body, .pricing-table-{$this->pricing_table_counter} .panel-footer{border-color:{$dividercolor};}
		.pricing-table-{$this->pricing_table_counter} .panel-body,.pricing-table-{$this->pricing_table_counter} .panel-footer{background-color:{$bordercolor};}
		</style>";

		$html = $styles . '<div ' . FusionBuilder::attributes( 'pricingtable-shortcode' ) . '>' . do_shortcode( $content ) . '</div>';

		$this->pricing_table_counter++;

		return $html;

	}

	/**
	 * Builds the attributes array.
	 *
	 * @access public
	 * @since 1.0
	 * @return array
	 */
	public function attr() {

		$attr = array();

		$type = 'sep';
		if ( '1' == self::$parent_args['type'] ) {
			$type = 'full';
		}

		$attr['class'] = 'fusion-pricing-table pricing-table-' . $this->pricing_table_counter . ' ' . $type . '-boxed-pricing row fusion-columns-' . self::$parent_args['columns'] . ' columns-' . self::$parent_args['columns'] . ' fusion-clearfix';

		$attr = fusion_builder_visibility_atts( self::$parent_args['hide_on_mobile'], $attr );

		if ( self::$parent_args['class'] ) {
			$attr['class'] .= ' ' . self::$parent_args['class'];
		}

		if ( self::$parent_args['id'] ) {
			$attr['id'] = self::$parent_args['id'];
		}

		return $attr;

	}

	/**
	 * Render the child shortcode
	 *
	 * @access public
	 * @since 1.0
	 * @param  array  $args    Shortcode parameters.
	 * @param  string $content Content between shortcode.
	 * @return string          HTML output.
	 */
	public function render_child_column( $args, $content = '' ) {

		$defaults = FusionBuilder::set_shortcode_defaults(
			array(
				'class'    => 'fusion-pricingtable-column',
				'id'       => '',
				'standout' => 'no',
				'title'    => '',
			), $args
		);

		extract( $defaults );

		self::$child_column_args = $defaults;

		$this->is_first_row = true;

		$html  = '<div ' . FusionBuilder::attributes( 'pricingtable-shortcode-column-wrapper' ) . '>';
		$html .= '<div ' . FusionBuilder::attributes( 'panel-container' ) . '>';
		$html .= '<div ' . FusionBuilder::attributes( 'fusion-panel' ) . '>';
		$html .= '<div ' . FusionBuilder::attributes( 'panel-heading' ) . '>';
		$html .= '<h3 ' . FusionBuilder::attributes( 'title-row' ) . '>' . $title . '</h3>';
		$html .= '</div>';
		$html .= do_shortcode( $content );

		if ( ! $this->is_list_group_closed ) {
			$html .= '</ul>';
		}

		$html .= '</div></div></div>';

		return $html;

	}

	/**
	 * Builds the column-wrapper attributes array.
	 *
	 * @access public
	 * @since 1.0
	 * @return array
	 */
	public function column_wrapper_attr() {

		$attr = array();

		$columns = 1;
		if ( self::$parent_args['columns'] ) {
			$columns = 12 / self::$parent_args['columns'];
		}

		$attr['class'] = 'panel-wrapper fusion-column column col-lg-' . $columns . ' col-md-' . $columns . ' col-sm-' . $columns;

		if ( '5' == self::$parent_args['columns'] ) {
			$attr['class'] = 'panel-wrapper fusion-column column col-lg-2 col-md-2 col-sm-2';
		}

		if ( 'yes' == self::$child_column_args['standout'] ) {
			$attr['class'] .= ' standout';
		}

		if ( self::$child_column_args['class'] ) {
			$attr['class'] .= ' ' . self::$child_column_args['class'];
		}

		if ( self::$child_column_args['id'] ) {
			$attr['id'] = self::$child_column_args['id'];
		}

		return $attr;

	}

	/**
	 * Render the child shortcode
	 *
	 * @access public
	 * @since 1.0
	 * @param  array  $args    Shortcode parameters.
	 * @param  string $content Content between shortcode.
	 * @return string          HTML output.
	 */
	public function render_child_price( $args, $content = '' ) {

		$defaults = FusionBuilder::set_shortcode_defaults(
			array(
				'currency'          => '',
				'currency_position' => 'left',
				'price'             => '',
				'time'              => '',
			), $args
		);

		extract( $defaults );

		$html = '<div ' . FusionBuilder::attributes( 'panel-body pricing-row' ) . '></div>' . do_shortcode( $content );

		if ( isset( $price ) && ( ! empty( $price ) || ( '0' == $price ) ) ) {

			$pricing_class = $pricing = '';
			$price = explode( '.' , $price );
			if ( array_key_exists( '1', $price ) ) {
				$pricing_class = 'price-with-decimal';
			}

			if ( 'right' != $currency_position ) {
				$pricing = '<span ' . FusionBuilder::attributes( 'currency' ) . '>' . $currency . '</span>';
			}

			$pricing .= '<span ' . FusionBuilder::attributes( 'integer-part' ) . '>' . $price[0] . '</span>';

			if ( array_key_exists( '1', $price ) ) {
				$pricing .= '<sup ' . FusionBuilder::attributes( 'decimal-part' ) . '>' . $price[1] . '</sup>';
			}

			if ( 'right' == $currency_position ) {
				$currency_classes = 'currency pos-right';
				$time_classes     = 'time pos-right';
				if ( ! array_key_exists( '1', $price ) ) {
					$currency_classes = 'currency pos-right price-without-decimal';
					$time_classes     = 'time pos-right price-without-decimal';
				}

				$pricing .= '<span ' . FusionBuilder::attributes( $currency_classes ) . '>' . $currency . '</span>';

				if ( $time ) {
					$pricing .= '<span ' . FusionBuilder::attributes( $time_classes ) . '>' . $time . '</span>';
				}
			}

			if ( $time && 'right' != $currency_position ) {
				$time_classes = 'time';
				if ( ! array_key_exists( '1', $price ) ) {
					$time_classes = 'time price-without-decimal';
				}

				$pricing .= '<span ' . FusionBuilder::attributes( $time_classes ) . '>' . $time . '</span>';
			}

			$html  = '<div ' . FusionBuilder::attributes( 'panel-body pricing-row' ) . '>';
			$html .= '<div ' . FusionBuilder::attributes( 'price ' . $pricing_class ) . '>' . $pricing . '</div></div>';
			$html .= do_shortcode( $content );

		}

		return $html;

	}

	/**
	 * Render the child shortcode
	 *
	 * @access public
	 * @since 1.0
	 * @param  array  $args    Shortcode parameters.
	 * @param  string $content Content between shortcode.
	 * @return string          HTML output.
	 */
	public function render_child_row( $args, $content = '' ) {

		$html = '';

		if ( $this->is_first_row ) {
			$html = '<ul ' . FusionBuilder::attributes( 'list-group' ) . '>';
			$this->is_first_row = false;
		}

		$html .= '<li ' . FusionBuilder::attributes( 'list-group-item normal-row' ) . '>' . do_shortcode( $content ) . '</li>';

		return $html;

	}

	/**
	 * Render the child shortcode
	 *
	 * @access public
	 * @since 1.0
	 * @param  array  $args    Shortcode parameters.
	 * @param  string $content Content between shortcode.
	 * @return string          HTML output.
	 */
	public function render_child_footer( $args, $content = '' ) {

		$html = '</ul><div ' . FusionBuilder::attributes( 'panel-footer footer-row' ) . '>' . do_shortcode( $content ) . '</div>';

		$this->is_list_group_closed = true;

		return $html;

	}

	/**
	 * Calculate the number of columns automatically.
	 *
	 * @access public
	 * @since 1.0
	 * @param string $content Content to be parsed.
	 */
	function set_num_of_columns( $content ) {
		if ( ! self::$parent_args['columns'] ) {
			preg_match_all( '/(\[fusion_pricing_column (.*?)\](.*?)\[\/fusion_pricing_column\])/s', $content, $matches );
			self::$parent_args['columns'] = 1;
			if ( is_array( $matches ) && ! empty( $matches ) ) {
				self::$parent_args['columns'] = count( $matches[0] );
				if ( self::$parent_args['columns'] > 6 ) {
					self::$parent_args['columns'] = 6;
				}
			}
		} elseif ( self::$parent_args['columns'] > 6 ) {
			self::$parent_args['columns'] = 6;
		}
	}
}
new FusionSC_PricingTable();

/**
 * Map shortcode to Fusion Builder
 *
 * @since 1.0
 */
function fusion_element_pricing_table() {
	fusion_builder_map( array(
		'name'       => esc_attr__( 'Pricing Table', 'fusion-builder' ),
		'shortcode'  => 'fusion_pricing_table',
		'icon'       => 'fusiona-dollar',
		'preview'    => FUSION_BUILDER_PLUGIN_DIR . 'js/previews/fusion-pricing-table-preview.php',
		'preview_id' => 'fusion-builder-block-module-pricing-table-preview-template',

		'custom_settings_view_name'     => 'ModuleSettingsTableView',
		'custom_settings_view_js'       => FUSION_BUILDER_PLUGIN_URL . 'inc/templates/custom/js/fusion-pricing-table-settings.js',
		'custom_settings_template_file' => FUSION_BUILDER_PLUGIN_DIR . 'inc/templates/custom/fusion-pricing-table-settings.php',
		// 'custom_settings_template_css'  => FUSION_BUILDER_PLUGIN_DIR . 'inc/templates/custom/css/fusion-pricing-table-settings.css',
		'on_save'           => 'pricingTableShortcodeFilter',
		'admin_enqueue_js'  => FUSION_BUILDER_PLUGIN_URL . 'shortcodes/js/fusion-pricing-table.js',
		'params'            => array(
			array(
				'type'        => 'radio_button_set',
				'heading'     => esc_attr__( 'Type', 'fusion-builder' ),
				'description' => esc_attr__( 'Select the type of pricing table.' ),
				'param_name'  => 'type',
				'value'       => array(
					esc_attr__( 'Style 1', 'fusion-builder' ) => '1',
					esc_attr__( 'Style 2', 'fusion-builder' ) => '2',
				),
				'default'     => '1',
			),
			array(
				'type'        => 'colorpickeralpha',
				'heading'     => esc_attr__( 'Background Color', 'fusion-builder' ),
				'description' => esc_attr__( 'Leave blank for default.', 'fusion-builder' ),
				'param_name'  => 'backgroundcolor',
				'value'       => '',
			),
			array(
				'type'        => 'colorpickeralpha',
				'heading'     => esc_attr__( 'Border Color', 'fusion-builder' ),
				'description' => esc_attr__( 'Leave blank for default.', 'fusion-builder' ),
				'param_name'  => 'bordercolor',
				'value'       => '',
			),
			array(
				'type'        => 'colorpickeralpha',
				'heading'     => esc_attr__( 'Divider Color', 'fusion-builder' ),
				'description' => esc_attr__( 'Leave blank for default.', 'fusion-builder' ),
				'param_name'  => 'dividercolor',
				'value'       => '',
			),
			array(
				'type'        => 'textarea',
				'heading'     => esc_attr__( 'Short Code', 'fusion-builder' ),
				'description' => esc_attr__( 'Pricing Table short code content.', 'fusion-builder' ),
				'param_name'  => 'element_content',
				'value'       => '[fusion_pricing_column title="Standard" standout="no" class="" id=""][fusion_pricing_price currency="$" price="15.55" time="monthly"][/fusion_pricing_price][fusion_pricing_row]Feature 1[/fusion_pricing_row][fusion_pricing_footer][/fusion_pricing_footer][/fusion_pricing_column][fusion_pricing_column title="Premium" standout="yes" class="" id=""][fusion_pricing_price currency="$" price="25.55" time="monthly"][/fusion_pricing_price][fusion_pricing_row]Feature 1[/fusion_pricing_row][fusion_pricing_footer][/fusion_pricing_footer][/fusion_pricing_column]',
			),
			array(
				'type'        => 'checkbox_button_set',
				'heading'     => esc_attr__( 'Element Visibility', 'fusion-builder' ),
				'param_name'  => 'hide_on_mobile',
				'value'       => fusion_builder_visibility_options( 'full' ),
				'default'     => fusion_builder_default_visibility( 'array' ),
				'description' => esc_attr__( 'Choose to show or hide the element on small, medium or large screens. You can choose more than one at a time.', 'fusion-builder' ),
			),
			array(
				'type'        => 'textfield',
				'heading'     => esc_attr__( 'CSS Class', 'fusion-builder' ),
				'description' => esc_attr__( 'Add a class to the wrapping HTML element.', 'fusion-builder' ),
				'param_name'  => 'class',
				'value'       => '',
				'group'       => esc_attr__( 'General', 'fusion-builder' ),
			),
			array(
				'type'        => 'textfield',
				'heading'     => esc_attr__( 'CSS ID', 'fusion-builder' ),
				'description' => esc_attr__( 'Add an ID to the wrapping HTML element.', 'fusion-builder' ),
				'param_name'  => 'id',
				'value'       => '',
				'group'       => esc_attr__( 'General', 'fusion-builder' ),
			),
		),
	) );
}
add_action( 'fusion_builder_before_init', 'fusion_element_pricing_table' );
